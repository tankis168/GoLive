/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : leavemodel.go is main program
*/

package main

import (
	"fmt"
	"math"
	"time"
)

func deleteleavedb(staffid, fdate string) int64 {
	db := dbConn()
	defer db.Close()
	sqlStatement := "delete from tleave where staffid=? and datefrom=?"
	res, err := db.Exec(sqlStatement, staffid, fdate)
	checkErr(err)
	affectedRows, err := res.RowsAffected()
	checkErr(err)
	fmt.Printf("Afftected %d rows\n", affectedRows)
	return affectedRows

}

func deletewfhdb(staffid, fdate string) int64 {
	db := dbConn()
	defer db.Close()
	sqlStatement := "delete from wfh where staffid=? and datefrom=?"
	res, err := db.Exec(sqlStatement, staffid, fdate)
	checkErr(err)
	affectedRows, err := res.RowsAffected()
	checkErr(err)
	fmt.Printf("Afftected %d rows\n", affectedRows)
	return affectedRows
}

func selectallwfhdb() {
	db := dbConn()
	defer db.Close()
	var mywfh Wfh
	selDB, err := db.Query("SELECT staffid,convert(datefrom, char),convert(dateto,char),wstatus FROM wfh")
	checkErr(err)

	for selDB.Next() {
		var id, wfd, wtd, wst string
		err = selDB.Scan(&id, &wfd, &wtd, &wst)
		if err != nil {
			panic(err.Error())
		} else {
			mywfh = Wfh{id, wfd, wtd, wst}
			wfhkey := id + wfd
			mapwfh[wfhkey] = mywfh
		}
	}
}

func selectallleavedb() {
	db := dbConn()
	defer db.Close()
	var myleave Leave
	selDB, err := db.Query("SELECT staffid,convert(datefrom, char),convert(dateto,char),dayuse,lstatus FROM tleave")
	checkErr(err)

	for selDB.Next() {
		var id, lfd, ltd, st, lduse string
		err = selDB.Scan(&id, &lfd, &ltd, &lduse, &st)
		if err != nil {
			panic(err.Error())
		} else {
			fmt.Println(id, lfd, ltd, st)
			myleave = Leave{id, lfd, ltd, lduse, st}
			leavekey := id + lfd
			mapleave[leavekey] = myleave
		}
	}
}

func insertwfhdb(staffid string, fdate, tdate time.Time) {
	db := dbConn()
	defer db.Close()
	fmt.Println(staffid, fdate, tdate)
	insForm, err := db.Prepare("INSERT INTO wfh(staffid, datefrom,dateto,dayuse,wstatus) VALUES(?,?,?,?,?)")
	if err != nil {
		panic(err.Error())
	} else {
		days := GetWeekdaysBetween(fdate, tdate)
		if days > 0 {
			insForm.Exec(staffid, fdate, tdate, days, "APPLY")
		}
	}

}

func insertleavedb(staffid, ind string, fdate, tdate time.Time) {
	db := dbConn()
	defer db.Close()

	insForm, err := db.Prepare("INSERT INTO tleave(staffid, datefrom,dateto,dayuse,lstatus) VALUES(?,?,?,?,?)")
	if err != nil {
		panic(err.Error())
	} else {
		var days float32
		if fdate == tdate {
			if ind != "-" {
				days = 0.5
			} else {
				days = 1.0
			}
		} else {
			days = float32(GetWeekdaysBetween(fdate, tdate))
		}
		if days > 0 {
			insForm.Exec(staffid, fdate, tdate, days, "APPLY")
		}
	}

}

func updateleavedb(staffid, ind, prevfdate, lst string, fdate, tdate time.Time) {
	db := dbConn()
	defer db.Close()
	updForm, err := db.Prepare("UPDATE tleave SET datefrom=?,dateto=?,dayuse=?,lstatus=? WHERE staffid=? and datefrom=?")
	checkErr(err)
	var days float32
	if fdate == tdate {
		if ind != "-" {
			days = 0.5
		} else {
			days = 1.0
		}
	} else {
		days = float32(GetWeekdaysBetween(fdate, tdate))
	}
	if days > 0 {
		if lst == "REJECTED" {
			days = 0
		}
		updForm.Exec(fdate, tdate, days, lst, staffid, prevfdate)
	}
}

func updatewfhdb(staffid, prevfdate, wst string, fdate, tdate time.Time) {
	db := dbConn()
	defer db.Close()
	updForm, err := db.Prepare("UPDATE wfh SET datefrom=?,dateto=?,dayuse=?,wstatus=? WHERE staffid=? and datefrom=?")
	checkErr(err)
	var days int
	days = GetWeekdaysBetween(fdate, tdate)
	if days > 0 {
		if wst == "REJECTED" {
			days = 0
		}
		updForm.Exec(fdate, tdate, days, wst, staffid, prevfdate)
	}
}

func GetWeekdaysBetween(start, end time.Time) int {
	offset := -int(start.Weekday())
	start = start.AddDate(0, 0, -int(start.Weekday()))

	offset += int(end.Weekday())
	if end.Weekday() == time.Sunday {
		offset++
	}
	end = end.AddDate(0, 0, -int(end.Weekday()))

	dif := end.Sub(start).Truncate(time.Hour * 24)
	weeks := float64((dif.Hours() / 24) / 7)
	return int(math.Round(weeks)*5) + offset
}

func showwfh(staffid string) {
	db := dbConn()
	defer db.Close()
	var mywfh Wfh

	selDB, err := db.Query("SELECT staffid,convert(datefrom, char),convert(dateto,char),wstatus FROM wfh where staffid=?", staffid)
	checkErr(err)
	for selDB.Next() {
		var id, wfd, wtd, st string
		err = selDB.Scan(&id, &wfd, &wtd, &st)
		if err != nil {
			panic(err.Error())
		} else {
			fmt.Println(id, wfd, wtd, st)

			mywfh = Wfh{id, wfd, wtd, st}
			wfhkey := id + wfd
			mapwfh[wfhkey] = mywfh
		}
	}
}

func showleave(staffid string) {
	db := dbConn()
	defer db.Close()
	var myleave Leave
	selDB, err := db.Query("SELECT staffid,convert(datefrom, char),convert(dateto,char),dayuse,lstatus FROM tleave where staffid=?", staffid)
	checkErr(err)

	for selDB.Next() {
		var id, lfd, ltd, st, lduse string
		err = selDB.Scan(&id, &lfd, &ltd, &lduse, &st)
		if err != nil {
			panic(err.Error())
		} else {
			fmt.Println(id, lfd, ltd, st)
			myleave = Leave{id, lfd, ltd, lduse, st}
			leavekey := id + lfd
			mapleave[leavekey] = myleave
		}
	}
}
