/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : common.go is main program
*/

package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"

	"github.com/gorilla/mux"
)

func checkio(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	//fmt.Fprintf(w, "New Method Detail for course "+params["staffid"])
	if r.Header.Get("Content-type") == "application/json" {
		if r.Method == "PUT" {
			var newCheck Check
			reqBody, err := ioutil.ReadAll(r.Body)
			if err != nil {
				fmt.Println(err)
			}
			json.Unmarshal(reqBody, &newCheck)
			checknew := rowcountdb(newCheck.Staffid)
			if checknew == 1 {
				iresult := updatedb(newCheck.Staffid)
				if iresult == 1 {
					w.WriteHeader(http.StatusCreated)
					w.Write([]byte("201 - Attendance added: " +
						newCheck.Staffid))
				} else {
					w.WriteHeader(http.StatusNotFound)
					w.Write([]byte("404 - No course found"))
				}
			}

		}
	}

	if r.Method == "POST" {
		var newCheck Check
		reqBody, err := ioutil.ReadAll(r.Body)
		if err == nil {
			json.Unmarshal(reqBody, &newCheck)
		}
		result := selectdb(newCheck.Staffid)
		if result == 1 {
			checknew := rowcountdb(newCheck.Staffid)
			if checknew == 0 {
				iresult := insertdb(newCheck.Staffid)
				if iresult == 1 {
					w.WriteHeader(http.StatusCreated)
					w.Write([]byte("201 - Attendance added: " +
						newCheck.Staffid))
				} else {
					w.WriteHeader(http.StatusNotFound)
					w.Write([]byte("404 - No Attendance found"))
				}
			}
		} else {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("404 - No course found"))
		}
	}

	if r.Method == "GET" {

		if params["staffid"] == "ADMIN" {
			v := r.URL.Query()
			if v["menu"][0] == "1" {
				selectcheckbymonthdb()
				json.NewEncoder(w).Encode(alist)
			}

			w.WriteHeader(http.StatusCreated)
		} else {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("404 - No Attendance found"))
		}

	}

}

func checkioall(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Show me from adminmenu function ")
	selectcheckbymonthdb()
	fmt.Println("Show me alist ", alist)
	json.NewEncoder(w).Encode(alist)
}

func staff(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	if r.Method == "DELETE" {
		if !validKey(r) {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("401 - Invalid key"))
			return
		}
		if _, ok := mapstaff[params["staffid"]]; ok {
			result := deletestaffdb(params["staffid"])
			if result == 1 {
				_, ok := mapstaff[params["staffid"]]
				if ok {
					delete(mapstaff, params["staffid"])
				}
			}
			w.WriteHeader(http.StatusNoContent)
		} else {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("404 - No course found"))
		}

	}

	if r.Header.Get("Content-type") == "application/json" {
		if r.Method == "PUT" {
			var newStaff staffList
			reqBody, err := ioutil.ReadAll(r.Body)
			if err == nil {
				json.Unmarshal(reqBody, &newStaff)
			}
			if _, ok := mapstaff[params["staffid"]]; ok {
				updatestaffdb(newStaff.Staffid, newStaff.Firstname, newStaff.Lastname,
					newStaff.Email, newStaff.Position, newStaff.Department)
				mapstaff[newStaff.Staffid] = staffList{newStaff.Staffid, newStaff.Firstname, newStaff.Lastname,
					newStaff.Email, newStaff.Position, newStaff.Department}
				w.WriteHeader(http.StatusNoContent)
			} else {
				w.WriteHeader(http.StatusNotFound)
				w.Write([]byte("404 - No course found"))
			}

		}
	}

	if r.Method == "POST" {
		var newStaff staffInfo
		reqBody, err := ioutil.ReadAll(r.Body)
		fmt.Println("Show request ", string(reqBody))
		if err == nil {
			json.Unmarshal(reqBody, &newStaff)
		}

		result := selectdb(newStaff.Staffid)
		if result == 0 {
			iresult := insertstaffdb(newStaff.Staffid,
				newStaff.Firstname, newStaff.Lastname,
				newStaff.Email, newStaff.Position, newStaff.Department,
				newStaff.Password)
			if iresult == 1 {
				w.WriteHeader(http.StatusCreated)
				w.Write([]byte("201 - Attendance added: " +
					newStaff.Staffid))
			} else {
				w.WriteHeader(http.StatusNotFound)
				w.Write([]byte("404 - No course found"))
			}
		}
	}

	if r.Method == "GET" {

		allcreddb(params["staffid"])

		if _, ok := acreds[params["staffid"]]; ok {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusCreated)
			sacred := aCredentials{acreds[params["staffid"]].Staffid, acreds[params["staffid"]].Password,
				acreds[params["staffid"]].Mykey, acreds[params["staffid"]].Firstname,
				acreds[params["staffid"]].Lastname, acreds[params["staffid"]].Email,
				acreds[params["staffid"]].Position, acreds[params["staffid"]].Department,
				acreds[params["staffid"]].Checkdatein}
			json.NewEncoder(w).Encode(sacred)
		} else {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("404 - No course found"))
		}
	}

}

func staffall(w http.ResponseWriter, r *http.Request) {
	selectstaffdb()
	json.NewEncoder(w).Encode(mapstaff)
}
