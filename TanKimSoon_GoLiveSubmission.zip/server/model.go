/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : model.go is main program
*/

package main

import (
	"database/sql"
	"fmt"
	"log"
	"os"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/joho/godotenv"
	uuid "github.com/satori/go.uuid"
)

func dbConn() (db *sql.DB) {
	err := godotenv.Load(".env")
	if err != nil {
		log.Fatal("Error loading .env file")
	}

	dbDriver := os.Getenv("MYDRIVER")
	dbUser := os.Getenv("MYUSER")
	dbPass := os.Getenv("MYREGISTER")
	dbName := os.Getenv("MYDB")
	dbHost := os.Getenv("MYHOST")

	db, err = sql.Open(dbDriver, dbUser+":"+dbPass+dbHost+dbName)
	if err != nil {
		panic(err.Error())
	}

	return db
}

func deletestaffdb(staffid string) int64 {
	db := dbConn()
	defer db.Close()
	insdb, err := db.Prepare("INSERT INTO a_staff (Select * from staff where staffid=?)")
	checkErr(err)
	insdb.Exec(staffid)
	fmt.Println("delete function ", staffid)
	sqlStatement := "delete from staff where staffid=?"
	res, err := db.Exec(sqlStatement, staffid)
	checkErr(err)
	affectedRows, err := res.RowsAffected()
	checkErr(err)
	fmt.Printf("Afftected %d rows\n", affectedRows)
	return affectedRows

}

func updatecheck() {
	db := dbConn()
	defer db.Close()
	sqlStatement := "Update attendance set checkoutdate=?,remark='System autogenerate: Forget checkout' where date(checkindate)=current_date()-1 and checkoutdate is null"
	curdt := time.Now()
	t := "18:00:00"
	ydate := curdt.AddDate(0, 0, -1).Format("2006-01-02")
	setdt := ydate + " " + t
	res, err := db.Exec(sqlStatement, setdt)
	checkErr(err)
	affectedRows, err := res.RowsAffected()
	checkErr(err)
	fmt.Printf("Afftected %d rows\n", affectedRows)

}

func selectstaffdb() {
	db := dbConn()
	defer db.Close()
	var mystaff staffList
	sqlStatement := `select staffid,firstname,lastname,email,position,department from staff order by lastupdate desc;`
	selDB, err := db.Query(sqlStatement)
	checkErr(err)
	for selDB.Next() {
		var id, fname, lname, email, pos, dept string
		err = selDB.Scan(&id, &fname, &lname, &email, &pos, &dept)
		if err != nil {
			panic(err.Error())
		} else {
			mystaff = staffList{id, fname, lname, email, pos, dept}
			mapstaff[id] = mystaff
		}
	}
}

func selectcheckbymonthdb() {
	db := dbConn()
	defer db.Close()
	var mylist listAttandce
	sqlStatement := `select s.staffid,s.firstname,s.lastname,s.department,
		convert(a.checkindate, char), if(a.checkoutdate is NULL,'CHECKOUT',convert(a.checkoutdate, char)) 
		FROM staff as s left join attendance as a on s.staffid=a.staffid where month(a.checkindate)=month(current_date()) 
		and year(a.checkindate)=year(current_date()) order by s.department,s.staffid,a.checkindate;`
	selDB, err := db.Query(sqlStatement)
	checkErr(err)

	for selDB.Next() {
		var id, fname, lname, dept, datei, dateo string
		err = selDB.Scan(&id, &lname, &fname, &dept, &datei, &dateo)
		if err != nil {
			panic(err.Error())
		} else {
			mylist = listAttandce{id, lname, fname, dept, datei, dateo}
			mylistkey := id + datei
			alist[mylistkey] = mylist
		}
	}
}

func allcreddb(staffid string) {
	db := dbConn()
	defer db.Close()
	var sqlStatement string
	var id, pwd, mkey, lname, fname, dept, eadr, pos, datei string
	var myacreds aCredentials
	checkres := checkdb(staffid)
	if checkres == 1 {
		sqlStatement = `SELECT s.staffid,s.password,s.mykey,s.firstname,s.lastname,s.email,s.position,s.department,
		convert(a.checkindate, char) FROM staff as s left join attendance as a on s.staffid=a.staffid 
		where s.staffid=? and date(a.checkindate)=current_date();`
	} else {
		sqlStatement = `SELECT s.staffid,s.password,s.mykey,s.firstname,s.lastname,s.email,s.position,s.department,
		"0" FROM staff as s where s.staffid=?;`
	}
	row := db.QueryRow(sqlStatement, staffid)

	switch err := row.Scan(&id, &pwd, &mkey, &fname, &lname, &eadr, &pos, &dept, &datei); err {
	case sql.ErrNoRows:
		fmt.Println("No rows were returned!")
	case nil:
		myacreds = aCredentials{id, pwd, mkey, fname, lname, eadr, pos, dept, datei}
		acreds[id] = myacreds
	default:
		panic(err)
	}
}

func checkdb(staffid string) int {
	db := dbConn()
	defer db.Close()
	selDB, err := db.Query("SELECT count(staffid) FROM attendance where staffid=? and date(checkindate)=current_date()", staffid)
	checkErr(err)
	for selDB.Next() {
		var id int
		err = selDB.Scan(&id)
		if err != nil {
			panic(err.Error())
		} else {
			return id
		}
	}
	return 0
}

func selectdb(staffid string) int {
	db := dbConn()
	defer db.Close()
	selDB, err := db.Query("SELECT count(staffid) FROM staff where staffid=?", staffid)
	checkErr(err)
	for selDB.Next() {
		var id int
		err = selDB.Scan(&id)
		if err != nil {
			panic(err.Error())
		} else {
			return id
		}
	}
	return 0
}

func findkeydb(mkey string) int {
	db := dbConn()
	defer db.Close()
	selDB, err := db.Query("SELECT count(mykey) FROM staff where mykey=?", mkey)
	checkErr(err)
	for selDB.Next() {
		var id int
		err = selDB.Scan(&id)
		if err != nil {
			panic(err.Error())
		} else {
			return id
		}
	}
	return 0
}

func rowcountdb(staffid string) int {
	db := dbConn()
	defer db.Close()
	dt := time.Now().Format("2006-01-02")
	selDB, err := db.Query("SELECT count(staffid) FROM attendance where staffid=? and date(checkindate)=?", staffid, dt)
	checkErr(err)
	for selDB.Next() {
		var id int
		err = selDB.Scan(&id)
		if err != nil {
			panic(err.Error())
		} else {
			return id
		}
	}
	return 0
}

func insertdb(id string) int {
	db := dbConn()
	defer db.Close()
	insForm, err := db.Prepare("INSERT INTO attendance(staffid, checkindate) VALUES(?,?)")
	checkErr(err)
	curdt := time.Now().Format("2006-01-02 15:04:05")
	insForm.Exec(id, curdt)
	result := rowcountdb(id)
	return result
}

func insertstaffdb(i, f, l, e, p, d string, pwd []byte) int {
	db := dbConn()
	defer db.Close()
	insstaffForm, err := db.Prepare("INSERT INTO staff(staffid,password,firstname,lastname,email,position,department,mykey) VALUES(?,?,?,?,?,?,?,?)")
	checkErr(err)
	myuuid := uuid.NewV4()
	insstaffForm.Exec(i, pwd, f, l, e, p, d, myuuid.String())
	result := checkdb(i)
	return result
}

func updatestaffdb(id, fname, lname, eadr, posi, dept string) {
	db := dbConn()
	defer db.Close()
	insstaffForm, err := db.Prepare("update staff set firstname=?,lastname=?,email=?,position=?,department=? where staffid=?")
	checkErr(err)
	insstaffForm.Exec(fname, lname, eadr, posi, dept, id)
}

func updatedb(id string) int {
	db := dbConn()
	defer db.Close()
	updForm, err := db.Prepare("UPDATE attendance SET checkoutdate=? WHERE staffid=? and date(checkindate)=?")
	checkErr(err)
	today := time.Now().Format("2006-01-02")
	curdt := time.Now().Format("2006-01-02 15:04:05")
	updForm.Exec(curdt, id, today)
	result := rowcountdb(id)
	return result
}

func checkErr(err error) {
	if err != nil {
		log.Fatal(err)
		panic(err)
	}
}
