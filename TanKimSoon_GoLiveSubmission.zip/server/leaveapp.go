/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : leaveapp.go is main program
*/

package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"

	"github.com/gorilla/mux"
)

func staffwfh(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)

	if r.Method == "DELETE" {
		if !validKey(r) {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("401 - Invalid key"))
			return
		}
		if _, ok := mapwfh[params["staffid"]]; ok {
			sid := mapwfh[params["staffid"]].Staffid
			wdatef := mapwfh[params["staffid"]].Wfhfdate
			result := deletewfhdb(sid, wdatef)
			if result == 1 {
				delete(mapwfh, params["staffid"])
			}
			w.WriteHeader(http.StatusNoContent)
		} else {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("404 - No course found"))
		}

	}

	if r.Header.Get("Content-type") == "application/json" {
		if r.Method == "PUT" {
			var newWfh Wfh
			reqBody, err := ioutil.ReadAll(r.Body)
			if err == nil {
				json.Unmarshal(reqBody, &newWfh)
			}
			wfhkey := newWfh.Staffid + newWfh.Wfhfdate
			fdate, err := time.Parse("2006-01-02", newWfh.Wfhfdate)
			if err != nil {
				panic(err)
			}
			tdate, err := time.Parse("2006-01-02", newWfh.Wfhtdate)
			if err != nil {
				panic(err)
			}
			prevdatefrom := mapwfh[params["staffid"]].Wfhfdate
			updatewfhdb(newWfh.Staffid, prevdatefrom, newWfh.Wstatus, fdate, tdate)
			delete(mapwfh, params["staffid"])
			mapwfh[wfhkey] = Wfh{newWfh.Staffid, newWfh.Wfhfdate, newWfh.Wfhtdate, newWfh.Wstatus}
			w.WriteHeader(http.StatusNoContent)
		} else {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("404 - No course found"))
		}
	}

	if r.Method == "POST" {
		var newWfh Wfh
		reqBody, err := ioutil.ReadAll(r.Body)
		if err == nil {
			json.Unmarshal(reqBody, &newWfh)
		}

		result := selectdb(newWfh.Staffid)
		if result == 1 {
			fdate, err := time.Parse("2006-01-02", newWfh.Wfhfdate)
			if err != nil {
				panic(err)
			}
			tdate, err := time.Parse("2006-01-02", newWfh.Wfhtdate)
			if err != nil {
				panic(err)
			}
			insertwfhdb(newWfh.Staffid, fdate, tdate)
		} else {
			w.WriteHeader(http.StatusCreated)
			w.Write([]byte("201 - Attendance added: " +
				newWfh.Staffid))
		}
	}

	if r.Method == "GET" {
		showwfh(params["staffid"])
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(mapwfh)
	}
}

func staffallwfh(w http.ResponseWriter, r *http.Request) {
	selectallwfhdb()
	json.NewEncoder(w).Encode(mapwfh)
}

func staffallleave(w http.ResponseWriter, r *http.Request) {
	selectallleavedb()
	json.NewEncoder(w).Encode(mapleave)
}

func staffleave(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	if r.Method == "DELETE" {
		if !validKey(r) {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("401 - Invalid key"))
			return
		}
		if _, ok := mapleave[params["staffid"]]; ok {
			sid := mapleave[params["staffid"]].Staffid
			ldatef := mapleave[params["staffid"]].Leavefdate
			result := deleteleavedb(sid, ldatef)
			if result == 1 {
				delete(mapleave, params["staffid"])
			}
			w.WriteHeader(http.StatusNoContent)
		} else {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("404 - No course found"))
		}

	}

	if r.Header.Get("Content-type") == "application/json" {
		if r.Method == "PUT" {
			var newLeave Leave
			reqBody, err := ioutil.ReadAll(r.Body)
			if err == nil {
				json.Unmarshal(reqBody, &newLeave)
			}
			leavekey := newLeave.Staffid + newLeave.Leavefdate
			fdate, err := time.Parse("2006-01-02", newLeave.Leavefdate)
			if err != nil {
				panic(err)
			}
			tdate, err := time.Parse("2006-01-02", newLeave.Leavetdate)
			if err != nil {
				panic(err)
			}
			prevdatefrom := mapleave[params["staffid"]].Leavefdate
			updateleavedb(newLeave.Staffid, newLeave.Leaveind, prevdatefrom, newLeave.Leavestatus, fdate, tdate)
			delete(mapleave, params["staffid"])
			mapleave[leavekey] = Leave{newLeave.Staffid, newLeave.Leavefdate, newLeave.Leavetdate, newLeave.Leaveind, newLeave.Leavestatus}
		} else {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("404 - No course found"))
		}
	}

	if r.Method == "POST" {

		var newLeave Leave
		reqBody, err := ioutil.ReadAll(r.Body)
		if err == nil {
			json.Unmarshal(reqBody, &newLeave)
		}
		leavekey := newLeave.Staffid + newLeave.Leavefdate
		fmt.Println("key : ", leavekey, "testing ", params["staffid"], " leave ", newLeave.Staffid, newLeave.Leaveind, newLeave.Leavefdate, newLeave.Leavetdate, newLeave.Leavestatus)

		fdate, err := time.Parse("2006-01-02", newLeave.Leavefdate)
		if err != nil {
			panic(err)
		}
		tdate, err := time.Parse("2006-01-02", newLeave.Leavetdate)
		if err != nil {
			panic(err)
		}
		value, ok := mapleave[params["staffid"]]
		if ok {
			fmt.Println("True", value)
		} else {
			fmt.Println("Flase", value)
		}
		insertleavedb(newLeave.Staffid, newLeave.Leaveind, fdate, tdate)
	}

	if r.Method == "GET" {
		showleave(params["staffid"])
		fmt.Println("method GET ", mapleave)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(mapleave)
	}

}
