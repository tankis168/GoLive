/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : server.go is main program
*/

package main

import (
	"fmt"
	"net/http"

	_ "github.com/go-sql-driver/mysql"
	"github.com/gorilla/mux"
)

type Check struct {
	Staffid string `json:"Staffid"`
	Menu    string `json:"Menu"`
}

type Credentials struct {
	Staffid  string `json:"Staffid"`
	Password string `json:"Password"`
	Mykey    string `json:"Mykey"`
}

type aCredentials struct {
	Staffid     string `json:"Staffid"`
	Password    string `json:"Password"`
	Mykey       string `json:"Mykey"`
	Firstname   string `json:"Firstname"`
	Lastname    string `json:"Lastname"`
	Email       string `json:"Email"`
	Position    string `json:"Position"`
	Department  string `json:"Department"`
	Checkdatein string `json:"Checkdatein"`
}

type listAttandce struct {
	Staffid      string `json:"Staffid"`
	Firstname    string `json:"Firstname"`
	Lastname     string `json:"Lastname"`
	Department   string `json:"Department"`
	Checkdatein  string `json:"Checkdatein"`
	Checkdateout string `json:"Checkdateout"`
}

type staffList struct {
	Staffid    string `json:"Staffid"`
	Firstname  string `json:"Firstname"`
	Lastname   string `json:"Lastname"`
	Email      string `json:"Email"`
	Position   string `json:"Position"`
	Department string `json:"Department"`
}

type staffInfo struct {
	Staffid    string `json:"Staffid"`
	Password   []byte `json:"Password"`
	Firstname  string `json:"Firstname"`
	Lastname   string `json:"Lastname"`
	Email      string `json:"Email"`
	Position   string `json:"Position"`
	Department string `json:"Department"`
}

type Wfh struct {
	Staffid  string `json:"Staffid"`
	Wfhfdate string `json:"Wfhfdate"`
	Wfhtdate string `json:"Wfhtdate"`
	Wstatus  string `json:"Wstatus"`
}

type Leave struct {
	Staffid     string `json:"Staffid"`
	Leavefdate  string `json:"Leavefdate"`
	Leavetdate  string `json:"Leavetdate"`
	Leaveind    string `json:"Leaveind"`
	Leavestatus string `json:"Leavestatus"`
}

var acreds = map[string]aCredentials{}
var alist = map[string]listAttandce{}
var mapwfh = map[string]Wfh{}
var mapstaff = map[string]staffList{}
var mapleave = map[string]Leave{}

func validKey(r *http.Request) bool {
	v := r.URL.Query()
	if key, ok := v["key"]; ok {
		result := findkeydb(key[0])
		if result == 1 {
			return true
		} else {
			return false
		}
	} else {
		return false
	}
}

func home(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Welcome to the REST API")
}

func main() {
	// Check staff that forget to checkout will be set the time 18:00:00
	updatecheck()
	router := mux.NewRouter()
	router.HandleFunc("/api/v1/", home)
	router.HandleFunc("/api/v1/checkio/{staffid}", checkio).Methods("GET", "PUT", "POST", "DELETE")
	router.HandleFunc("/api/v1/staff/{staffid}", staff).Methods("GET", "PUT", "POST", "DELETE")
	router.HandleFunc("/api/v1/staffwfh/{staffid}", staffwfh).Methods("GET", "PUT", "POST", "DELETE")
	router.HandleFunc("/api/v1/staffleave/{staffid}", staffleave).Methods("GET", "PUT", "POST", "DELETE")
	router.HandleFunc("/api/v1/staffleave", staffallleave)
	router.HandleFunc("/api/v1/staffwfh", staffallwfh)
	router.HandleFunc("/api/v1/staff", staffall)
	router.HandleFunc("/api/v1/checkio", checkioall)
	fmt.Println("Listening at port  5000")
	http.ListenAndServe(":5000", router)
}
