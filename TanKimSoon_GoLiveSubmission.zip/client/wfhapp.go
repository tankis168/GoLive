/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : wfhapp.go is main program
*/

package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

func Deletewfh(w http.ResponseWriter, r *http.Request) {
	staffid := r.URL.Query().Get("id")
	request, err := http.NewRequest(http.MethodDelete,
		baseURLc+"/"+staffid+"?key="+basekey, nil)
	showErr(err)
	client := &http.Client{}
	response, err := client.Do(request)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ := ioutil.ReadAll(response.Body)
		fmt.Println(string(data))
	}
	delete(mapwfh, staffid)
	response.Body.Close()
	http.Redirect(w, r, "/usermenu", 301)
}

func Approvewfh(w http.ResponseWriter, r *http.Request) {
	wfhkey := r.URL.Query().Get("id")
	sid := Wfh{mapwfh[wfhkey].Staffid,
		mapwfh[wfhkey].Wfhfdate,
		mapwfh[wfhkey].Wfhtdate,
		"APPROVED"}
	jsonValue, _ := json.Marshal(sid)
	request, err := http.NewRequest(http.MethodPut,
		baseURLc+"/"+wfhkey, bytes.NewBuffer(jsonValue))
	showErr(err)
	request.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	response, err := client.Do(request)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		delete(mapwfh, wfhkey)
		data, _ := ioutil.ReadAll(response.Body)
		fmt.Println(string(data))
		errorhandle("Wfh", gstaffid, hostn())
	}
	response.Body.Close()
	http.Redirect(w, r, "/adminmenu", 301)

}

func Rejectwfh(w http.ResponseWriter, r *http.Request) {
	wfhkey := r.URL.Query().Get("id")
	sid := Wfh{mapwfh[wfhkey].Staffid,
		mapwfh[wfhkey].Wfhfdate,
		mapwfh[wfhkey].Wfhtdate,
		"REJECTED"}
	jsonValue, _ := json.Marshal(sid)
	request, err := http.NewRequest(http.MethodPut,
		baseURLc+"/"+wfhkey, bytes.NewBuffer(jsonValue))
	showErr(err)
	request.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	response, err := client.Do(request)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		delete(mapwfh, wfhkey)
		data, _ := ioutil.ReadAll(response.Body)
		fmt.Println(response.StatusCode)
		fmt.Println(string(data))
		errorhandle("Wfh", gstaffid, hostn())
	}
	response.Body.Close()
	http.Redirect(w, r, "/adminmenu", 301)
}

func Editwfh(w http.ResponseWriter, r *http.Request) {
	wfhkey := r.URL.Query().Get("id")
	if r.Method == "POST" {
		wfhkeya := r.FormValue("wfhkeya")
		wfhfdate := r.FormValue("wfhfdate")
		wfhtdate := r.FormValue("wfhtdate")
		if wfhfdate != "" && wfhtdate != "" {
			sid := Wfh{gstaffid, wfhfdate, wfhtdate, "APPLY"}
			jsonValue, _ := json.Marshal(sid)
			request, err := http.NewRequest(http.MethodPut,
				baseURLc+"/"+wfhkeya, bytes.NewBuffer(jsonValue))
			showErr(err)
			request.Header.Set("Content-Type", "application/json")
			client := &http.Client{}
			response, err := client.Do(request)
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			} else {
				delete(mapwfh, wfhkeya)
				data, _ := ioutil.ReadAll(response.Body)
				fmt.Println(response.StatusCode)
				fmt.Println(string(data))
				errorhandle("Wfh", gstaffid, hostn())
			}
			response.Body.Close()
			http.Redirect(w, r, "/usermenu", 301)
		}

	}
	tmpl.ExecuteTemplate(w, "Editwfh", mapwfh[wfhkey])

}

func Applywfh(w http.ResponseWriter, r *http.Request) {
	var maptempwfh = make(map[string]Wfh)
	var awfh = make(map[string]interface{})
	mywfh := Wfh{}
	response, err := http.Get(baseURLc + "/" + gstaffid)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ := ioutil.ReadAll(response.Body)
		err := json.Unmarshal([]byte(data), &awfh)
		showErr(err)
		for k, v := range awfh {
			if mv, ok := v.(map[string]interface{}); ok {
				if gstaffid == mv["Staffid"].(string) {
					mywfh = Wfh{
						Staffid:  mv["Staffid"].(string),
						Wfhfdate: mv["Wfhfdate"].(string)[0:10],
						Wfhtdate: mv["Wfhtdate"].(string)[0:10],
						Wstatus:  mv["Wstatus"].(string),
					}
					maptempwfh[k] = mywfh
					mapwfh[k] = mywfh
				}
			}
		}

	}

	tmpl.ExecuteTemplate(w, "Applywfh", maptempwfh)
}

func Newwfh(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		wfhfdate := r.FormValue("wfhfdate")
		wfhtdate := r.FormValue("wfhtdate")
		if wfhfdate != "" && wfhtdate != "" {

			sid := Wfh{gstaffid, wfhfdate, wfhtdate, "APPLY"}
			jsonValue, _ := json.Marshal(sid)
			response, err := http.Post(baseURLc+"/"+gstaffid,
				"application/json", bytes.NewBuffer(jsonValue))
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			}
			response.Body.Close()
			errorhandle("Wfh", gstaffid, hostn())
		}
		http.Redirect(w, r, "/usermenu", 301)
	}
	tmpl.ExecuteTemplate(w, "Newwfh", nil)
}

func Showadmwfh(w http.ResponseWriter, r *http.Request) {
	var awfh = make(map[string]interface{})
	mywfh := Wfh{}
	response, err := http.Get(baseURLc)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ := ioutil.ReadAll(response.Body)
		err := json.Unmarshal([]byte(data), &awfh)
		showErr(err)
		for k, v := range awfh {
			if mv, ok := v.(map[string]interface{}); ok {
				mywfh = Wfh{
					Staffid:  mv["Staffid"].(string),
					Wfhfdate: mv["Wfhfdate"].(string)[0:10],
					Wfhtdate: mv["Wfhtdate"].(string)[0:10],
					Wstatus:  mv["Wstatus"].(string),
				}
				mapwfh[k] = mywfh
			}
		}

	}
	tmpl.ExecuteTemplate(w, "Showadmwfh", mapwfh)
}
