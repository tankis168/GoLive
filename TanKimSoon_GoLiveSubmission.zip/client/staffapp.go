/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : staffapp.go is main program
*/

package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"

	"golang.org/x/crypto/bcrypt"
)

func Deletestaff(w http.ResponseWriter, r *http.Request) {
	staffid := r.URL.Query().Get("id")
	request, err := http.NewRequest(http.MethodDelete,
		baseURLa+"/"+staffid+"?key="+basekey, nil)
	showErr(err)
	client := &http.Client{}
	response, err := client.Do(request)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		delete(mapstaff, staffid)
		data, _ := ioutil.ReadAll(response.Body)
		fmt.Println(string(data))

	}
	response.Body.Close()
	http.Redirect(w, r, "/adminmenu", 301)
}

func Signup(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		staffid := r.FormValue("staffid")
		password := r.FormValue("password")
		firstname := r.FormValue("firstname")
		lastname := r.FormValue("lastname")
		email := r.FormValue("email")
		position := r.FormValue("position")
		department := r.FormValue("department")
		if staffid != "" && firstname != "" && lastname != "" && password != "" {
			staffid = strings.ToUpper(staffid)
			firstname = strings.ToUpper(firstname)
			lastname = strings.ToUpper(lastname)
			bPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.MinCost)
			if err != nil {
				http.Error(w, "Internal server error", http.StatusInternalServerError)
				return
			}
			sid := staffInfo{staffid, bPassword, firstname, lastname, email, position, department}
			jsonValue, _ := json.Marshal(sid)
			response, err := http.Post(baseURLa+"/"+staffid,
				"application/json", bytes.NewBuffer(jsonValue))
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			}
			response.Body.Close()
		}
		http.Redirect(w, r, "/", 301)
	}
	tmpl.ExecuteTemplate(w, "Signup", nil)
}

func Editstaff(w http.ResponseWriter, r *http.Request) {
	staffid := r.URL.Query().Get("id")
	if r.Method == "POST" {
		staffid := r.FormValue("staffid")
		firstname := r.FormValue("firstname")
		lastname := r.FormValue("lastname")
		email := r.FormValue("email")
		position := r.FormValue("position")
		department := r.FormValue("department")
		if staffid != "" {
			sid := staffList{staffid, firstname, lastname, email, position, department}
			jsonValue, _ := json.Marshal(sid)
			request, err := http.NewRequest(http.MethodPut,
				baseURLa+"/"+staffid, bytes.NewBuffer(jsonValue))
			showErr(err)
			request.Header.Set("Content-Type", "application/json")
			client := &http.Client{}
			response, err := client.Do(request)
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			} else {
				delete(mapstaff, staffid)
				data, _ := ioutil.ReadAll(response.Body)
				fmt.Println(string(data))
				errorhandle("Staff", gstaffid, hostn())
			}
			response.Body.Close()
			http.Redirect(w, r, "/adminmenu", 301)
		}
	}
	tmpl.ExecuteTemplate(w, "Editstaff", mapstaff[staffid])

}

func Showstaff(w http.ResponseWriter, r *http.Request) {
	var mystaff staffList
	var astaff map[string]interface{}
	response, err := http.Get(baseURLa)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		fmt.Println(response.Body)
		data, _ := ioutil.ReadAll(response.Body)
		err := json.Unmarshal([]byte(data), &astaff)
		showErr(err)
		for k, v := range astaff {
			if mv, ok := v.(map[string]interface{}); ok {
				mystaff = staffList{
					Staffid:    mv["Staffid"].(string),
					Firstname:  mv["Firstname"].(string),
					Lastname:   mv["Lastname"].(string),
					Email:      mv["Email"].(string),
					Position:   mv["Position"].(string),
					Department: mv["Department"].(string),
				}
				mapstaff[k] = mystaff
			}
		}
	}
	tmpl.ExecuteTemplate(w, "Showstaff", mapstaff)
}
