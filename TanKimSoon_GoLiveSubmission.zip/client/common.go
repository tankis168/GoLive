/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : common.go is main program
*/

package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"text/template"
	"time"

	jwt "github.com/dgrijalva/jwt-go"
	"golang.org/x/crypto/bcrypt"
)

var tmpl = template.Must(template.ParseGlob("templates/*"))
var jwtTokenSecret = "ac12b3d45e6f"
var gstaffid string
var leavekey string
var basekey string
var acreds map[string]interface{}

func Index(w http.ResponseWriter, r *http.Request) {
	tmpl.ExecuteTemplate(w, "Checkin", nil)
}

func Dattendancelist(w http.ResponseWriter, r *http.Request) {
	currentdate := time.Now().Format("2006-01-02")
	var allcheck = map[string]listAttandce{}
	var aleave map[string]interface{}
	var mylist listAttandce
	response, err := http.Get(baseURL)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ := ioutil.ReadAll(response.Body)
		err := json.Unmarshal([]byte(data), &aleave)
		if err != nil {
			fmt.Println(err)
		}
		var cnt int
		for k, v := range aleave {
			if mv, ok := v.(map[string]interface{}); ok {
				chkdatein := mv["Checkdatein"].(string)[0:10]
				if chkdatein == currentdate {
					cnt++
					mylist = listAttandce{
						Staffid:      mv["Staffid"].(string),
						Firstname:    mv["Firstname"].(string),
						Lastname:     mv["Lastname"].(string),
						Department:   mv["Department"].(string),
						Checkdatein:  mv["Checkdatein"].(string),
						Checkdateout: mv["Checkdateout"].(string),
					}
					allcheck[k] = mylist
				}
			}
		}
	}
	tmpl.ExecuteTemplate(w, "Dattendancelist", allcheck)

}

func Adminmenu(w http.ResponseWriter, r *http.Request) {
	var allcheck = map[string]listAttandce{}
	var aleave map[string]interface{}
	var mylist listAttandce
	response, err := http.Get(baseURL)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ := ioutil.ReadAll(response.Body)
		err := json.Unmarshal([]byte(data), &aleave)
		if err != nil {
			fmt.Println(err)
		}
		for k, v := range aleave {
			if mv, ok := v.(map[string]interface{}); ok {

				mylist = listAttandce{
					Staffid:      mv["Staffid"].(string),
					Firstname:    mv["Firstname"].(string),
					Lastname:     mv["Lastname"].(string),
					Department:   mv["Department"].(string),
					Checkdatein:  mv["Checkdatein"].(string),
					Checkdateout: mv["Checkdateout"].(string),
				}
				allcheck[k] = mylist
			}
		}
	}
	tmpl.ExecuteTemplate(w, "Adminmenu", allcheck)
}

func Usermenu(w http.ResponseWriter, r *http.Request) {
	var allcreds = map[string]aCredentials{}
	var myacreds aCredentials
	myacreds = aCredentials{
		Staffid:     acreds["Staffid"].(string),
		Password:    acreds["Password"].(string),
		Mykey:       acreds["Mykey"].(string),
		Firstname:   acreds["Firstname"].(string),
		Lastname:    acreds["Lastname"].(string),
		Email:       acreds["Email"].(string),
		Position:    acreds["Position"].(string),
		Department:  acreds["Department"].(string),
		Checkdatein: acreds["Checkdatein"].(string),
	}
	allcreds[gstaffid] = myacreds
	tmpl.ExecuteTemplate(w, "Usermenu", allcreds)
}

func Checkout(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		staffid := r.FormValue("staffid")
		if staffid != "" {
			staffid = strings.ToUpper(staffid)
			sid := Staff{staffid, staffid}
			jsonValue, _ := json.Marshal(sid)
			request, err := http.NewRequest(http.MethodPut,
				baseURL+"/"+staffid, bytes.NewBuffer(jsonValue))
			showErr(err)
			request.Header.Set("Content-Type", "application/json")
			client := &http.Client{}
			response, err := client.Do(request)
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			} else {
				errorhandle("Checkout", staffid, hostn())
				response.Body.Close()
			}
		}
		http.Redirect(w, r, "/", 301)
	}
	tmpl.ExecuteTemplate(w, "Checkout", nil)
}

func Checkin(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		staffid := r.FormValue("staffid")
		if staffid != "" {
			staffid = strings.ToUpper(staffid)
			sid := Staff{staffid, staffid}
			jsonValue, _ := json.Marshal(sid)
			response, err := http.Post(baseURL+"/"+staffid,
				"application/json", bytes.NewBuffer(jsonValue))
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			}
			errorhandle("Checkin", staffid, hostn())
			response.Body.Close()
		}
		http.Redirect(w, r, "/", 301)
	}
	tmpl.ExecuteTemplate(w, "Checkin", nil)
}

func Login(w http.ResponseWriter, r *http.Request) {
	conditionsMap := map[string]interface{}{}
	// check if user already logged in
	staffid, _ := ExtractTokenStaffid(r)
	if staffid != "" { // user already logged in!
		conditionsMap["Staffid"] = staffid
		conditionsMap["LoginError"] = false
	}

	if r.Method == "POST" {
		staffid := r.FormValue("staffid")
		password := r.FormValue("password")
		if staffid != "" && password != "" {
			staffid = strings.ToUpper(staffid)
			url := baseURLa + "/" + staffid
			response, err := http.Get(url)
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			}

			data, _ := ioutil.ReadAll(response.Body)
			json.Unmarshal([]byte(data), &acreds)
			pwd := acreds["Password"].(string)
			err = bcrypt.CompareHashAndPassword([]byte(pwd), []byte(password))
			if err != nil {
				http.Error(w, "Username and/or password do not match", http.StatusForbidden)
			} else {
				gstaffid = staffid
				basekey = acreds["Mykey"].(string)
				conditionsMap["Staffid"] = staffid
				conditionsMap["LoginError"] = false

				// create a new JSON Web Token and redirect to dashboard
				tokenString, err := CreateToken(staffid)

				if err != nil {
					log.Println(err)
					os.Exit(1)
				}

				expirationTime := time.Now().Add(1 * time.Hour) // cookie expired after 1 hour

				cookie := &http.Cookie{
					Name:    "token",
					Value:   tokenString,
					Expires: expirationTime,
				}

				http.SetCookie(w, cookie)

				errorhandle("Login", staffid, hostn())
				if staffid == "ADMIN" {
					http.Redirect(w, r, "/adminmenu", 301)
				} else {
					http.Redirect(w, r, "/usermenu", 301)
				}
			}

		}
	}

	tmpl.ExecuteTemplate(w, "Login", nil)
}

func Logout(w http.ResponseWriter, r *http.Request) {
	// Setting MaxAge<0 means delete cookie now.
	errorhandle("Logout", gstaffid, hostn())
	gstaffid = ""
	basekey = ""
	c := http.Cookie{
		Name:   "token",
		MaxAge: -1}
	http.SetCookie(w, &c)

	//w.Write([]byte("Old cookie deleted. Logged out!\n"))
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func CreateToken(staffid string) (string, error) {
	claims := jwt.MapClaims{}
	claims["authorized"] = true
	claims["staffid"] = staffid                              //embed username inside the token string
	claims["expired"] = time.Now().Add(time.Hour * 1).Unix() //Token expires after 1 hour
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(jwtTokenSecret))
}

func ExtractTokenStaffid(r *http.Request) (string, error) {
	// get our token string from Cookie
	biscuit, err := r.Cookie("token")

	var tokenString string
	if err != nil {
		tokenString = ""
	} else {
		tokenString = biscuit.Value
	}

	// abort
	if tokenString == "" {
		return "", nil
	}

	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(jwtTokenSecret), nil
	})
	if err != nil {
		return "", err
	}
	claims, ok := token.Claims.(jwt.MapClaims)
	if ok && token.Valid {
		username := fmt.Sprintf("%s", claims["staffid"]) // convert to string
		if err != nil {
			return "", err
		}
		return username, nil
	}
	return "", nil
}
