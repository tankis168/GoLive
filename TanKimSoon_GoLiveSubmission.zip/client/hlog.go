/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : hlog.go is main program
*/

package main

import (
	"fmt"
	"log"
	"os"
	"time"
)

func errorhandle(iname string, username string, remark string) {
	ensuredir("logs")
	ensuredir("logs/" + iname)

	filename := "logs/" + iname + "/" + iname + "_" + time.Now().Format("2006_01_02") + ".log"
	fmt.Println(filename)
	f, err := os.OpenFile(filename, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Println(err)
	}
	defer f.Close()

	logger := log.New(f, iname+": "+remark+" "+username+" ", log.Ldate|log.Ltime|log.Lshortfile)
	logger.Println("")

}

func ensuredir(folder string) {
	_, err := os.Stat(folder)

	if os.IsNotExist(err) {
		errDir := os.MkdirAll(folder, 0755)
		if errDir != nil {
			log.Fatal(err)
		}

	}
}
