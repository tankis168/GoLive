/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : leaveapp.go is main program
*/

package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

func Deleteleave(w http.ResponseWriter, r *http.Request) {
	staffid := r.URL.Query().Get("id")
	request, err := http.NewRequest(http.MethodDelete,
		baseURLb+"/"+staffid+"?key="+basekey, nil)
	showErr(err)
	client := &http.Client{}
	response, err := client.Do(request)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ := ioutil.ReadAll(response.Body)
		fmt.Println(response.StatusCode)
		fmt.Println(string(data))
	}
	delete(mapleave, staffid)
	response.Body.Close()
	http.Redirect(w, r, "/usermenu", 301)
}

func Approveleave(w http.ResponseWriter, r *http.Request) {
	leavekey := r.URL.Query().Get("id")
	sid := Leave{mapleave[leavekey].Staffid,
		mapleave[leavekey].Leavefdate,
		mapleave[leavekey].Leavetdate,
		mapleave[leavekey].Leaveind,
		"APPROVED"}
	jsonValue, _ := json.Marshal(sid)
	request, err := http.NewRequest(http.MethodPut,
		baseURLb+"/"+leavekey, bytes.NewBuffer(jsonValue))
	showErr(err)
	request.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	response, err := client.Do(request)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		delete(mapleave, leavekey)
		data, _ := ioutil.ReadAll(response.Body)
		fmt.Println(response.StatusCode)
		fmt.Println(string(data))
		errorhandle("Leave", gstaffid, hostn())
	}
	response.Body.Close()
	http.Redirect(w, r, "/adminmenu", 301)
}

func Rejectleave(w http.ResponseWriter, r *http.Request) {
	leavekey := r.URL.Query().Get("id")
	sid := Leave{mapleave[leavekey].Staffid,
		mapleave[leavekey].Leavefdate,
		mapleave[leavekey].Leavetdate,
		mapleave[leavekey].Leaveind,
		"REJECTED"}
	jsonValue, _ := json.Marshal(sid)
	request, err := http.NewRequest(http.MethodPut,
		baseURLb+"/"+leavekey, bytes.NewBuffer(jsonValue))
	showErr(err)
	request.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	response, err := client.Do(request)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		delete(mapleave, leavekey)
		data, _ := ioutil.ReadAll(response.Body)
		fmt.Println(response.StatusCode)
		fmt.Println(string(data))
		errorhandle("Leave", gstaffid, hostn())
	}
	response.Body.Close()
	http.Redirect(w, r, "/adminmenu", 301)
}

func Editleave(w http.ResponseWriter, r *http.Request) {
	leavekey = r.URL.Query().Get("id")
	if r.Method == "POST" {
		leavekeya := r.FormValue("leavekeya")
		leavefdate := r.FormValue("leavefdate")
		leavetdate := r.FormValue("leavetdate")
		leaveind := r.FormValue("leaveind")
		if leavefdate != "" && leavetdate != "" && leaveind != "" {
			sid := Leave{gstaffid, leavefdate, leavetdate, leaveind, "APPLY"}
			jsonValue, _ := json.Marshal(sid)
			request, err := http.NewRequest(http.MethodPut,
				baseURLb+"/"+leavekeya, bytes.NewBuffer(jsonValue))
			showErr(err)
			request.Header.Set("Content-Type", "application/json")
			client := &http.Client{}
			response, err := client.Do(request)
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			} else {
				delete(mapleave, leavekeya)
				data, _ := ioutil.ReadAll(response.Body)
				fmt.Println(string(data))
				errorhandle("Leave", gstaffid, hostn())
			}
			response.Body.Close()
			http.Redirect(w, r, "/usermenu", 301)
		}
	}
	tmpl.ExecuteTemplate(w, "Editleave", mapleave[leavekey])

}

func Applyleave(w http.ResponseWriter, r *http.Request) {
	var maptempleave = make(map[string]Leave)
	var aleave = make(map[string]interface{})
	myleave := Leave{}
	response, err := http.Get(baseURLb + "/" + gstaffid)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ := ioutil.ReadAll(response.Body)
		err := json.Unmarshal([]byte(data), &aleave)
		showErr(err)
		for k, v := range aleave {
			if mv, ok := v.(map[string]interface{}); ok {
				if gstaffid == mv["Staffid"].(string) {
					myleave = Leave{
						Staffid:     mv["Staffid"].(string),
						Leavefdate:  mv["Leavefdate"].(string)[0:10],
						Leavetdate:  mv["Leavetdate"].(string)[0:10],
						Leaveind:    mv["Leaveind"].(string),
						Leavestatus: mv["Leavestatus"].(string),
					}
					maptempleave[k] = myleave
					mapleave[k] = myleave
				}

			}
		}

	}
	tmpl.ExecuteTemplate(w, "Applyleave", maptempleave)
}

func Showadmleave(w http.ResponseWriter, r *http.Request) {
	var aleave = make(map[string]interface{})
	myleave := Leave{}
	response, err := http.Get(baseURLb)
	if err != nil {
		fmt.Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ := ioutil.ReadAll(response.Body)
		err := json.Unmarshal([]byte(data), &aleave)
		showErr(err)
		for k, v := range aleave {
			if mv, ok := v.(map[string]interface{}); ok {
				myleave = Leave{
					Staffid:     mv["Staffid"].(string),
					Leavefdate:  mv["Leavefdate"].(string)[0:10],
					Leavetdate:  mv["Leavetdate"].(string)[0:10],
					Leaveind:    mv["Leaveind"].(string),
					Leavestatus: mv["Leavestatus"].(string),
				}
				mapleave[k] = myleave
			}
		}

	}
	tmpl.ExecuteTemplate(w, "Showadmleave", mapleave)
}

func Newleave(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		leavefdate := r.FormValue("leavefdate")
		leavetdate := r.FormValue("leavetdate")
		leaveind := r.FormValue("leaveind")
		if leavefdate != "" && leavetdate != "" && leaveind != "" {
			sid := Leave{gstaffid, leavefdate, leavetdate, leaveind, "APPLY"}
			jsonValue, _ := json.Marshal(sid)
			response, err := http.Post(baseURLb+"/"+gstaffid,
				"application/json", bytes.NewBuffer(jsonValue))
			if err != nil {
				fmt.Printf("The HTTP request failed with error %s\n", err)
			}
			fmt.Println(response.StatusCode)
			errorhandle("Leave", gstaffid, hostn())
		}
		http.Redirect(w, r, "/usermenu", 301)
	}
	tmpl.ExecuteTemplate(w, "Newleave", nil)
}
