/*
	Project Go Live

	Assignment:
		Course Title : Go School - Project Go Live Run 4
		Student : Tan Kim Soon
		Assignment : Web REST API Application - Checkin and Checkout System
		Program Code base on Go Version go1.6.2 darwin/amd64
		Remark : client.go is main program
*/

package main

import (
	"fmt"
	"log"
	"net/http"
)

type Staff struct {
	Staffid string `json:"Staffid"`
	Menu    string `json:"Menu"`
}

type staffInfo struct {
	Staffid    string `json:"Staffid"`
	Password   []byte `json:"Password"`
	Firstname  string `json:"Firstname"`
	Lastname   string `json:"Lastname"`
	Email      string `json:"Email"`
	Position   string `json:"Position"`
	Department string `json:"Department"`
}

type staffList struct {
	Staffid    string `json:"Staffid"`
	Firstname  string `json:"Firstname"`
	Lastname   string `json:"Lastname"`
	Email      string `json:"Email"`
	Position   string `json:"Position"`
	Department string `json:"Department"`
}

type Credentials struct {
	Staffid  string `json:"Staffid"`
	Password string `json:"Password"`
	Mykey    string `json:"Mykey"`
}

type Wfh struct {
	Staffid  string `json:"Staffid"`
	Wfhfdate string `json:"Wfhfdate"`
	Wfhtdate string `json:"Wfhtdate"`
	Wstatus  string `json:"Wstatus"`
}

type Leave struct {
	Staffid     string `json:"Staffid"`
	Leavefdate  string `json:"Leavefdate"`
	Leavetdate  string `json:"Leavetdate"`
	Leaveind    string `json:"Leaveind"`
	Leavestatus string `json:"Leavestatus"`
}

type listAttandce struct {
	Staffid      string `json:"Staffid"`
	Firstname    string `json:"Firstname"`
	Lastname     string `json:"Lastname"`
	Department   string `json:"Department"`
	Checkdatein  string `json:"Checkdatein"`
	Checkdateout string `json:"Checkdateout"`
}

type aCredentials struct {
	Staffid     string `json:"Staffid"`
	Password    string `json:"Password"`
	Mykey       string `json:"Mykey"`
	Firstname   string `json:"Firstname"`
	Lastname    string `json:"Lastname"`
	Email       string `json:"Email"`
	Position    string `json:"Position"`
	Department  string `json:"Department"`
	Checkdatein string `json:"Checkdatein"`
}

const baseURL = "http://localhost:5000/api/v1/checkio"
const baseURLa = "http://localhost:5000/api/v1/staff"
const baseURLb = "http://localhost:5000/api/v1/staffleave"
const baseURLc = "http://localhost:5000/api/v1/staffwfh"

var allcreds = map[string]aCredentials{}
var allwfh = map[string]Wfh{}
var allleave = map[string]Leave{}
var allcheck = map[string]listAttandce{}
var staffs = map[string]staffInfo{}
var mapwfh = map[string]Wfh{}
var mapleave = map[string]Leave{}
var mapstaff = map[string]staffList{}

func main() {
	http.HandleFunc("/", Index)
	http.HandleFunc("/checkin", Checkin)
	http.HandleFunc("/checkout", Checkout)
	http.HandleFunc("/login", Login)
	http.HandleFunc("/logout", Logout)
	http.HandleFunc("/signup", Signup)
	http.HandleFunc("/usermenu", Usermenu)
	http.HandleFunc("/adminmenu", Adminmenu)
	http.HandleFunc("/applywfh", Applywfh)
	http.HandleFunc("/applyleave", Applyleave)
	http.HandleFunc("/newwfh", Newwfh)
	http.HandleFunc("/newleave", Newleave)
	http.HandleFunc("/showstaff", Showstaff)
	http.HandleFunc("/dattendancelist", Dattendancelist)
	http.HandleFunc("/deletewfh", Deletewfh)
	http.HandleFunc("/editwfh", Editwfh)
	http.HandleFunc("/deleteleave", Deleteleave)
	http.HandleFunc("/editleave", Editleave)
	http.HandleFunc("/deletestaff", Deletestaff)
	http.HandleFunc("/editstaff", Editstaff)
	http.HandleFunc("/showadmleave", Showadmleave)
	http.HandleFunc("/approveleave", Approveleave)
	http.HandleFunc("/rejectleave", Rejectleave)
	http.HandleFunc("/showadmwfh", Showadmwfh)
	http.HandleFunc("/approvewfh", Approvewfh)
	http.HandleFunc("/rejectwfh", Rejectwfh)

	http.Handle("/favicon.ico", http.NotFoundHandler())
	err := http.ListenAndServeTLS(":8080", "cert/cert.pem", "cert/key.pem", nil)
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	} else {
		fmt.Println("Successful")
	}

}
